#pragma once
#include "Global.h"
#include "Function.h"

DWORD WINAPI ProcessThread(LPVOID arg);
DWORD WINAPI ClientThread(LPVOID arg);