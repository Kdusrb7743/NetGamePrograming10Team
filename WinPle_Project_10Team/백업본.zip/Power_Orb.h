#ifndef _POWER_ORB_
#define _POWER_ORB_
#include <stdlib.h>
#include <time.h>
#include <Windows.h>
#include <tchar.h>
#include <atlImage.h>
#include "Power_Math.h"
#include "resource.h"
//--------------------------------------------------------------------------------------------------------------//
extern HINSTANCE g_hInst;
extern LPCTSTR lpszClass, lpszWindowName;
extern const bool debug, keyboard;
extern const double window_size, window_size_x, window_size_y, Pibot_x, Pibot_y, Reactor_radius, Reflector_size_x, Reflector_size_y, Orb_size, Orb_radius;
LRESULT CALLBACK WndProc(HWND hwnd, UINT iMessage, WPARAM wparam, LPARAM lparam);
//--------------------------------------------------------------------------------------------------------------//
struct Power_Effect
{
	double x, y, score;
	int age;
	struct Power_Effect* next;
};
struct Power_Orb
{
	double x, y, speed, angle, power, size;
	double speedx, speedy;
	int type, effect;
};
struct Power_Reflector
{
	double angle, position, speed, size;
	int module[5], age;
};
extern bool Cherenkov;
extern double Score, Temperture, Mole;
extern int Cherenkov_meter, Time, PreTime;
extern struct Power_Effect* EffectHead;
//--------------------------------------------------------------------------------------------------------------//
struct Power_Effect* CreateEffect(struct Power_Effect* Effect, double x, double y, double Score);
struct Power_Effect* RemoveEffect(struct Power_Effect* Effect, struct Power_Effect* NextEffect);
struct Power_Effect* EffectPrint(struct Power_Effect* Effect, HDC hdc);
//--------------------------------------------------------------------------------------------------------------//
void ScoreUI(HDC hdc);
void DebugInfo(LPPOINT lpPoint, TCHAR lpOut[100], HDC hdc, struct Power_Orb* Orb, struct Power_Reflector Reflector);
void Display(HDC hdc, HDC memdc, HBITMAP hBitmap, CImage ReactorImg, CImage ReflectorImg, CImage OrbImg, POINT P_Point[3], struct Power_Orb* Orb);
void Display2(HDC mem1dc, HDC mem2dc, CImage ReactorImg, CImage ReflectorImg, CImage OrbImg, HBITMAP BitReactor, HBITMAP BitReflector, HBITMAP BitOrb, POINT P_Point[3], LPPOINT lpPoint, TCHAR lpOut[100], HDC hdc, struct Power_Orb* Orb, struct Power_Reflector Reflector);
//--------------------------------------------------------------------------------------------------------------//
POINT RotatePaint1(double x, double y, double angle, double sizex, double sizey);
POINT RotatePaint2(double x, double y, double angle, double sizex, double sizey);
POINT RotatePaint3(double x, double y, double angle, double sizex, double sizey);
POINT ReflectorPaint1(struct Power_Reflector Reflector);
POINT ReflectorPaint2(struct Power_Reflector Reflector);
POINT ReflectorPaint3(struct Power_Reflector Reflector);
//--------------------------------------------------------------------------------------------------------------//
bool CollisionCheck(struct Power_Orb* Orb, struct Power_Reflector Reflector);
//--------------------------------------------------------------------------------------------------------------//
struct Power_Orb* OrbReset(struct Power_Orb* Orb);
struct Power_Orb* OrbPosition(struct Power_Orb* Orb);
struct Power_Orb* OrbSpeed(struct Power_Orb* Orb);
struct Power_Orb* OrbReflect(struct Power_Orb* Orb, struct Power_Reflector Reflector);
struct Power_Orb* ReactorReflect(struct Power_Orb* Orb);
struct Power_Orb* ReflectDetect(struct Power_Orb* Orb, struct Power_Reflector Reflector);
//--------------------------------------------------------------------------------------------------------------//
struct Power_Reflector ReflectorReflect(struct Power_Reflector Reflector, struct Power_Orb* Orb);
struct Power_Reflector ReflectorPosition(struct Power_Reflector Reflector, bool Left, bool Right, bool Shift, bool Up, bool Down);
struct Power_Reflector ReflectorReset(struct Power_Reflector Reflector);
#endif