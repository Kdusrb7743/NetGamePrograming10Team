//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Resource.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     103
#define IDC_RADIO1                      1001
#define IDC_RADIO2                      1002
#define IDC_RADIO3                      1003
#define IDC_RADIO4                      1004
#define IDC_RADIO5                      1005
#define IDC_RADIO6                      1006
#define IDC_RADIO7                      1007
#define IDC_RADIO8                      1008
#define IDC_RADIO9                      1009
#define IDC_RADIO10                     1010
#define IDC_RADIO11                     1011
#define IDC_RADIO12                     1012
#define IDC_RADIO13                     1013
#define IDC_RADIO14                     1014
#define IDC_RADIO15                     1015
#define IDC_CHECK1                      1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
